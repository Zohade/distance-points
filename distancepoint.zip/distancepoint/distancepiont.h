#ifndef DISTANCEPIONT_H
#define DISTANCEPIONT_H
 struct point
{
    int x;
    int y;
}typedef point;



#endif // DISTANCEPIONT_H
