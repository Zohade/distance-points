#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "distancepiont.h"


int main()
{point point1,point2;
    double resultat=0;
    printf ("donner les coordonnees du premier  point \n x : ");
    scanf("%d", &point1.x);

    printf ("donner les coordonnees du premier  point \n y : ");
    scanf("%d", &point1.y);

    printf ("donner les coordonnees du deuxieme  point \n x : ");
    scanf("%d", &point2.x);

    printf ("donner les coordonnees du deuxieme  point \n y : ");
    scanf("%d", &point2.y);

    resultat=(sqrt((-point1.x + point2.x)*(-point1.x + point2.x)+(-point1.y + point2.y)*(-point1.y + point2.y)));


    printf(" la distance entre les deux points est : %f\n", resultat);

    return 0;
}
